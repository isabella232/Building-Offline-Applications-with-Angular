export interface CommentsEntity {
    IdxCommentId?: number;
    title: string;
    comments: string;
    timeCommented: string;
    gameId: number;
    userName:string;
}