export const environment = {
  boardGameServiceUrl: `/api/board-games`,
  commentsServiceUrl: '/api/board-games/comments',
  boardGamesByIdServiceUrl: '/api/board-games/gameById',
  production: true,
};
